<?php
namespace resource\modules;

use std, gui, framework, resource;


class AppModule extends AbstractModule
{

}