<?php
namespace resource\modules;

use std, gui, framework, resource;


class MainModule extends AbstractModule
{

}