<?php
namespace resource\forms;

use std, gui, framework, resource;


class MainForm extends AbstractForm
{

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        global $modeCoube;
        $modeCoube = False;
        
        $nameApplication = 'UmiconForm';
        $imageApplication = 'application';
        
        $this->messaApplication->text = $nameApplication;
        $this->imageApplication->image = new UXImage('res://resource/images/icons/' . $imageApplication . '.png');
    }
    
    /**
     * @event buttonClose.mouseEnter 
     */
    function doButtonCloseMouseEnter(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($e->sender, 100, 1.0);
    }

    /**
     * @event buttonClose.mouseExit 
     */
    function doButtonCloseMouseExit(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($e->sender, 100, 0.5);
    }

    /**
     * @event buttonCoube.mouseEnter 
     */
    function doButtonCoubeMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 100, 1.0);
    }

    /**
     * @event buttonCoube.mouseExit 
     */
    function doButtonCoubeMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 100, 0.5);
    }

    /**
     * @event buttonCuipe.mouseEnter 
     */
    function doButtonCuipeMouseEnter(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 100, 1.0);
    }

    /**
     * @event buttonCuipe.mouseExit 
     */
    function doButtonCuipeMouseExit(UXMouseEvent $e = null)
    {
        Animation::fadeTo($e->sender, 100, 0.5);
    }

    /**
     * @event buttonClose.click-Left 
     */
    function doButtonCloseClickLeft(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this, 200, 0.0, function () {
            $this->hide();
        });
    }

    /**
     * @event buttonCoube.click-Left 
     */
    function doButtonCoubeClickLeft(UXMouseEvent $e = null)
    {    
        global $modeCoube;
        
        if ($modeCoube == False) { $modeCoube = True;
            Animation::fadeTo($this, 200, 0.0, function () {
                $this->maximize();
                $this->panelForm->borderRadius = 0;
                $this->panelForm->draggingForm->disable();
                $this->buttonCoube->graphic = new UXImageView(new UXImage('res://resource/images/icons/decoube.png'));
                Animation::fadeTo($this, 200, 1.0);
            });
        } else { $modeCoube = False;
            Animation::fadeTo($this, 200, 0.0, function () {
                $this->size = [880, 480];
                $this->centerOnScreen();
                $this->panelForm->borderRadius = 10;
                $this->panelForm->draggingForm->enable();
                $this->buttonCoube->graphic = new UXImageView(new UXImage('res://resource/images/icons/coube.png'));
                Animation::fadeTo($this, 200, 1.0);
            });
        }
    }

    /**
     * @event buttonCuipe.click-Left 
     */
    function doButtonCuipeClickLeft(UXMouseEvent $e = null)
    {    
        Animation::fadeTo($this, 200, 0.0, function () {
            $this->iconified = True;
            $this->opacity = 1.0;
        });
    }

}
